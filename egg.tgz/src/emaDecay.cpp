// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Update EMA shadow\n", stdout);
  return lionss_run_workload("emaDecay");
}
