// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scan packages"); }
int main(){
  announce();
  return lionss_run_workload("glint");
}
