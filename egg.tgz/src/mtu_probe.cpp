// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Discover path MTU");
  std::fflush(stdout);
  return lionss_run_workload("mtu_probe");
}
