// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hash with XXH3\n", stdout);
  return lionss_run_workload("xxhash3");
}
